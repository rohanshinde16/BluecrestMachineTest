export const environment = {
  production: false,
  firebaseConfig : {
     apiKey: "AIzaSyBYbqS-qoEQaTKs8gpe4owWJyxIIzoAxFw",
    authDomain: "crud-d438d.firebaseapp.com",
    databaseURL: "https://crud-d438d.firebaseio.com",
    projectId: "crud-d438d",
    storageBucket: "crud-d438d.appspot.com",
    messagingSenderId: "209534676253"
  }
};